<?php
if(empty($_SESSION)) // if the session not yet started
    session_start();
include('mysql_connect.php');
$user = $_POST["usr"];
$pass = $_POST["pass"];
//$result = mysqli_query($conn, "SELECT * FROM `ilp_project.users` WHERE `user`='".$user."' AND `pass`='".$pass."'");
//echo "myFunction(1)";
$result = mysqli_query($conn, "SELECT * FROM users WHERE username='".$user."' AND pass='".$pass."'");
//echo "myFunction(2)";
if (mysqli_num_rows($result)>0) {
    $_SESSION['user'] = $user;
    header('Location: user_page.php?user=' . $user);
    exit;
}
 else{
     header('Location: index.php?wrong=1');
     exit;
    }

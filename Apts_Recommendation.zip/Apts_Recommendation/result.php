<?php
include('mysql_connect.php');
$method = '';
$check = False;
if(empty($_SESSION)) // if the session not yet started
    session_start();
if(!isset($_SESSION['user'])) { //if not yet logged in
    header("Location: index.php");// send to login page
    exit;
}

if(isset($_GET['review'])) {
    $check=True;
    // id index exists
    if($_GET['method']==4){
        $sql = "SELECT `price`, `bed`, `bath`,`zip`,`Area` FROM `linear_m` inner join `listing_res`on `listing_res`.`Entry_Num`=`linear_m`.`Entry_N`where `linear_m`.`entry_N`=".$_GET['entry'];
        $method='linear';
    }
    elseif($_GET['method']==5){
        $sql = "SELECT `price_hl`, `bed`, `bath`,`zip`,`Area` FROM `logistic_m` inner join `listing_res`on `listing_res`.`Entry_Num`=`logistic_m`.`Entry_N`where `logistic_m`.`entry_n`=".$_GET['entry'];
        $method='logistic';

    }
    //$sql = "SELECT * FROM `listing_res` WHERE `Bed`= ".$_GET['bed']." AND `Bath`= ".$_GET['bath']." AND `Zip`= '".$_GET['zip']."'";
    //SELECT `price`, `bed`, `bath`,`zip` FROM `linear_m` inner join `listing_res`on `listing_res`.`Entry_Num`=`linear_m`.`Entry_N`where `linear_m`.`entry_N`=
}
else{
    $beds = $_POST['bed'];
    $baths = $_POST['bath'];
    $num_select = rand(1,2);
    if($num_select % 2 == 0){
        //Linear Method
        $method = 'linear';
        $sql = "select `price`,`Area`,`Entry_Num` from `linear_m`INNER JOIN `listing_res` on `linear_m`.`Entry_N`= `listing_res`.`Entry_Num`where `listing_res`.`Bed`=".$_POST['bed']." and `listing_res`.`Bath`=".$_POST['bath']." and `listing_res`.`Zip`='".$_POST['zip']."'";
    }
    else{
        //Logistic Selection
        $method='logistic';
        $sql = "select `price_hl`,`Area`,`Entry_Num` from `logistic_m` INNER JOIN `listing_res` on `logistic_m`.`Entry_N`= `listing_res`.`Entry_Num`where `listing_res`.`Bed`=".$_POST['bed']." and `listing_res`.`Bath`=".$_POST['bath']." and `listing_res`.`Zip`='".$_POST['zip']."'";
    }
    $result = mysqli_query($conn, $sql);
    $dte = date("Y-m-d");
    $usr = $_SESSION['user'];
    while ($row = mysqli_fetch_array($result)) {
        $result1 = mysqli_query($conn, "INSERT INTO `search_hist` (`transaction_id`, `username`, `date`, `entry_n`, `result_method`) VALUES (NULL, '".$usr."', '".$dte."', '".$row['Entry_Num']."', '".$method."')");
        //echo $result1;
    }
}
?>
<!doctype html>
<html>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>F5 - System</title>
    <style>
        #loader {
            position: absolute;
            left: 50%;
            top: 50%;
            z-index: 1;
            width: 150px;
            height: 150px;
            margin: -75px 0 0 -75px;
            border: 16px solid green;
            border-left: 16px solid blue;
            border-radius: 50%;
            border-top: 16px solid red;
            border-bottom: 16px solid yellow;
            width: 120px;
            height: 120px;
            -webkit-animation: spin 2s linear infinite;
            animation: spin 2s linear infinite;
        }

        @-webkit-keyframes spin {
            0% { -webkit-transform: rotate(0deg); }
            100% { -webkit-transform: rotate(360deg); }
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Add animation to "page content" */
        .animate-bottom {
            position: relative;
            -webkit-animation-name: animatebottom;
            -webkit-animation-duration: 1s;
            animation-name: animatebottom;
            animation-duration: 1s
        }

        @-webkit-keyframes animatebottom {
            from { bottom:-100px; opacity:0 }
            to { bottom:0px; opacity:1 }
        }

        @keyframes animatebottom {
            from{ bottom:-100px; opacity:0 }
            to{ bottom:0; opacity:1 }
        }

        #main_content {
            display: none;
            text-align: center;
        }
        #main_content {
            width: 600px;
            height: 500px;
            position:absolute; /*it can be fixed too*/
            left:0; right:0;
            top:0; bottom:0;
            margin:auto;
            /*this to solve "the content will not be cut when the window is smaller than the content": */
            max-width:100%;
            max-height:100%;
            overflow:auto;
        }
        #main_content: h1{
            vertical-align: center;
            align-self: center;
        }
    </style>


</head>
<body class="bg" onload="loading()" style="margin: 0;">
<?php include('user_header.html');?>
<main>
<div id="loader"></div>
<div class="container" id="main_content">
    <h4>Based on your given criteria, <br>the base rent for your property should be: </h4>
    <table class="table table-dark table-striped">
        <thead>
        <tr>
            <th scope="col"># Beds</th>
            <th scope="col"># Bath</th>
            <th scope="col">Area (Sq.ft)</th>
            <th scope="col">Rent/mo</th>
        </tr>
        </thead>
        <tbody>
    <?php
    $result = mysqli_query($conn, $sql);
    if ($result) {
        while ($row = mysqli_fetch_array($result)) {
            // do something with the $row
            if($check){
                $beds=$row['bed'];
                $baths=$row['bath'];
            }
            echo "<tr>";
            echo "<td>" . $beds . "</td>";
            echo "<td>" . $baths . "</td>";
            echo "<td>" . $row['Area'] . "</td>";
            echo "<td>";  if ($method == 'linear') echo $row['price']."</td>";
            else{
                if($row['price_hl']==1){
                    echo "HIGH (>$3000)</td>";
                }
                elseif ($row['price_hl']==0){
                    echo "LOW (<$3000)</td>";
                }

            }
            echo "</tr>";
        }
    }
    else{
    echo "Error retrieving, please try again.";}
    ?></tbody>
    </table>
    <form action="feedback.php" method="post" onsubmit="">
    <fieldset class="form-group" required>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="rating" id="inlineRadio1" value="2">
            <label class="form-check-label" for="inlineRadio1">1</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="rating" id="inlineRadio2" value="2">
            <label class="form-check-label" for="inlineRadio2">2</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="rating" id="inlineRadio2" value="3">
            <label class="form-check-label" for="inlineRadio2">3</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="rating" id="inlineRadio2" value="4">
            <label class="form-check-label" for="inlineRadio2">4</label>
        </div>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="rating" id="inlineRadio2" value="5">
            <label class="form-check-label" for="inlineRadio2">5</label>
        </div>
    </fieldset>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="submit" value="Please Rate" <?php if($check) echo "disabled";?>>
        </div>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script>
    var myVar;

    function loading() {
        myVar = setTimeout(showPage, 4000);
    }
    function showPage() {
        document.getElementById("loader").style.display = "none";
        document.getElementById("main_content").style.display = "block";
    }

</script>
</main>
</body>
</html>

<!doctype html>
<html lang="en">
<head>
</head>
<body>
<form name="login_form" action="" onsubmit="<?php
$user=$_POST['user'];
$pass = $_POST['pass'];
$sql2 ="SELECT * FROM `users` WHERE `username`='".$user."' AND `pass`='".$pass."'";

$result = mysqli_query($conn, $sql2) or die(mysqli_error($conn));
$rows = mysqli_num_rows($result);

if ($rows==1) {
    echo "<script type='text/javascript'>alert('Login Credentials verified')</script>";
    //header("Location: /apts_recommendation/user_page.php?user=".$user."");
}
else {
    echo "<script type='text/javascript'>alert('Some Error')</script>";
    //header("Location: /apts_recommendation/index.php?login=0");
}
?>" method="post">
    <div class="form-group">
        <input type="text" class="form-control" placeholder="Username" name="user" required="required">
    </div>
    <div class="form-group">
        <input type="password" class="form-control" placeholder="Password" name="pass" required="required">
    </div>
    <input type="submit" class="btn btn-primary btn-block" value="Login">
</form>
</body>
</html>
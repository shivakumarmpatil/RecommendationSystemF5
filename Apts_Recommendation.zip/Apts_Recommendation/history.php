<?php
include('mysql_connect.php');
if(empty($_SESSION)) // if the session not yet started
    session_start();
if(!isset($_SESSION['user'])) { //if not yet logged in
    header("Location: index.php");// send to login page
    exit;
}
?>
<!doctype html>
<html>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>F5 - System</title>
    <style>
        .bg {
            background-image: url("https://www.aveliving.com/AVE/media/Property_Images/Florham%20Park/hero/flor-apt-living-(2)-hero.jpg?ext=.jpg");
            background-repeat: no-repeat;
        }
        input[type="range"]::-moz-range-track {
            padding: 0 10px;
            background: repeating-linear-gradient(to right,
            #ccc,
            #ccc 10%,
            #000 10%,
            #000 11%,
            #ccc 11%,
            #ccc 20%);
        }
    </style>


</head>
<body class="bg" style="background-color: ">
<?php include('user_header.html');?>
<div class="container">
<table class="table table-striped table-dark">
    <thead>
    <tr>
        <th scope="col">Date</th>
        <th scope="col">No. Of Beds</th>
        <th scope="col">No. Of Baths</th>
        <th scope="col">Zipcode</th>
        <th scope="col">Suggested Price</th>
        <th scope="col">Initial Rating</th>
        <th scope="col">Delayed Rating</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $result = mysqli_query($conn, "select `date`, `bed`, `bath`, `first_feed`, `late_feed`, `entry_n`,`Zip`,`result_method`,`transaction_id` from `search_hist`
left join `feedback` on `t_id` = `transaction_id`
inner join `listing_res` on `entry_num`=`entry_n`
where `username`='".$_SESSION['user']."'");
    if ($result) {
        while($row = mysqli_fetch_array($result)) {
            // do something with the $row
            $meth = 4;
            if($row['result_method']=='linear'){
                $meth = 4;
            }
            elseif($row['result_method']=='logistic'){
                $meth = 5;
            }
            echo "<tr>";
            echo "<td>".$row['date']."</td>";
            echo "<td>".$row['bed']."</td>";
            echo "<td>".$row['bath']."</td>";
            echo "<td>".$row['Zip']."</td>";
            echo "<td><a href='result.php?review=1&entry=".$row['entry_n']."&method=".$meth."' >See Result</a></td>";
            if($row['first_feed']==null){
                $row['first_feed']='NA';
            }
            echo "<td>".$row['first_feed']."</td>";
            if(!$row['late_feed']==null)
            echo "<td>".$row['late_feed']."</td>";
            else
                echo "<td><form method='post' action='feedback.php?tid=".$row['transaction_id']."'><input type='range' min='0' max='5' step='1' list='nums' name='rating'>
<datalist>
<option value='0'></option>
  <option value='1'></option>
  <option value='2\'></option>
  <option value='3'></option>
  <option value='4'></option>
  <option value='5'></option></datalist><input class=\"btn btn-primary btn-sm active\" type='submit' role=\"button\" aria-pressed=\"true\"></form></td>";
            echo "</tr>";
        }

    }
    else {
        echo mysqli_error();
    }
    ?>
    </tbody>
</table>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</body>
</html>
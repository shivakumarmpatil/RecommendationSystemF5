<?php
include('mysql_connect.php');
$usr=$_POST['uname'];
$result = mysqli_query($conn, "INSERT INTO `users` (`username`, `pass`, `secret`) VALUES ('".$_POST['uname']."', '".$_POST['pwd']."', '".$_POST['secret']."')");
echo $result;
if ($result) {
    if(empty($_SESSION)) // if the session not yet started
        session_start();
    if(!isset($_SESSION['user'])) {
        $_SESSION['user']=$usr;
    }
    header('Location: user_page.php');
    exit;
} else {
    echo "Error: <br>" . $conn->error;
}
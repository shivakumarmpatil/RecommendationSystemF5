<?php
include('mysql_connect.php');
if(empty($_SESSION)) // if the session not yet started
    session_start();
if(!isset($_SESSION['user'])) { //if not yet logged in
    header("Location: index.php");// send to login page
    exit;
}
if(isset($_GET['tid'])) {
    $feed = $_POST['rating'];
    $tid = $_GET['tid'];
    $sql = "INSERT INTO `feedback` (`t_id`,`late_feed`) VALUES (".$tid.",".$feed.") ON DUPLICATE KEY UPDATE `late_feed`=".$feed;
}
else {
    $feed = $_POST['rating'];
    $sql = "INSERT INTO `feedback` (`t_id`, `first_feed`)  
SELECT max(`transaction_id`), " . $feed . "
FROM `search_hist`";
}
$result = mysqli_query($conn, $sql);
if($result){
    header('Location: history.php');
}
else{
    echo "Error rating";
}

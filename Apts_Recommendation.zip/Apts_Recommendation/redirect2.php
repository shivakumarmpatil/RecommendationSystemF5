<?php
include('mysql_connect.php');
    $user = $_POST['userr'];
    $pass = $_POST['pwdd'];
    $q = $_POST['secrett'];
    $result1 = mysqli_query($conn, "SELECT * FROM `users` WHERE `username`='".$user."' AND `secret`='".$q."'");
    $result = mysqli_query($conn, "UPDATE `users` SET `pass`='".$pass."' WHERE `username`='".$user."' AND `secret`='".$q."'");
    $row = mysqli_fetch_array($result1);
    if (empty($row)){
        echo '<script language="javascript">';
        echo 'alert("Incorrect info Submitted") </script>';
    }
    elseif($result){

        echo $result;

        echo empty($row);
        //header('Location: index.php');
    }
    else{
    }
    echo " <a type=\"submit\" href='forgot.php'>Back</a>";

<!doctype html>
<html>
<head></head>
<body>
<form action="redirect2.php" method="post"><br>
    <input type="text" name="userr" placeholder="username">
    <br><br>
    <input type="text" name="secrett" placeholder="Your place of birth">
    <br><br>
    <input type="text" name="pwdd" placeholder="New Password">
    <br><br>
    <input type="submit" value="Submit">
</form>
</body>
</html>
